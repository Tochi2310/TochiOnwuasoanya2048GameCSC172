package graphicsPanels;


import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import gameLogic.DrawUtils;
import gameLogic.Game;
import gameLogic.GameRecords;

public class GameRecordsPanel extends GuiPanel{

	private GameRecords lBoard;
	private int buttonWidth = 100;
	private int backButtonWidth = 220;
	private int buttonSpacing = 20;
	private int buttonY = 120;
	private int buttonHeight = 50;
	private int leaderboardsX = 130;
	private int leaderboardsY = buttonY + buttonHeight + 90;
	
	private String title = "GameRecords";
	private Font titleFont = Game.main.deriveFont(48f);
	private Font scoreFont = Game.main.deriveFont(30f);
	private State currentState = State.SCORE;
	
	public GameRecordsPanel(){
		super();
		lBoard = GameRecords.getInstance();
		lBoard.loadScores();

		
		GuiButton scoreButton = new GuiButton(Game.WIDTH / 2 - buttonWidth / 2 + buttonSpacing, buttonY, buttonWidth, buttonHeight); //Button Dimensions
		scoreButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				currentState = State.SCORE;
			}
		});
		scoreButton.setText("Scores");//Button text
		add(scoreButton);//Adds button
		
		GuiButton timeButton = new GuiButton(Game.WIDTH / 2 + buttonWidth / 2 + buttonSpacing, buttonY, buttonWidth, buttonHeight); //Button Dimensions
		timeButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				currentState = State.TIME;
			}
		});
		timeButton.setText("Times");//Button text
		add(timeButton);//Adds button
		
		GuiButton backButton = new GuiButton(Game.WIDTH / 2 - backButtonWidth / 2, 500, backButtonWidth, 60);  //Button Dimensions
		backButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				GuiScreen.getInstance().setCurrentPanel("Menu");
			}
		});
		backButton.setText("Back");//Button text
		add(backButton); //Adds button
	}
	
	private void drawLeaderboards(Graphics2D g){ //Converts
		ArrayList<String> strings = new ArrayList<String>();
		if(currentState == State.SCORE){
			strings = convertToStrings(lBoard.getTopScores());
		}
		else {
			for(Long l : lBoard.getTopTimes()){
				strings.add(DrawUtils.formatTime(l));
			}
		}
		
		g.setColor(Color.black);
		g.setFont(scoreFont);
		
		for(int i = 0; i < strings.size(); i++){
			String s = (i + 1) + ". " + strings.get(i);
			g.drawString(s, leaderboardsX, leaderboardsY + i * 40);
		}
	}
	
	private ArrayList<String> convertToStrings(ArrayList<? extends Number> list){
		ArrayList<String> ret = new ArrayList<String>();
		for(Number n : list){
			ret.add(n.toString());
		}
		return ret;
	}
	
	@Override
	public void update(){
		
	}
	
	@Override
	public void render(Graphics2D g){
		super.render(g);
		g.setColor(Color.black);
		g.drawString(title, Game.WIDTH / 2 - DrawUtils.getMessageWidth(title, titleFont, g) / 2, DrawUtils.getMessageHeight(title, titleFont, g) + 40);
		drawLeaderboards(g);
	}
	
	private enum State{
		SCORE,
		TIME
	}
}
