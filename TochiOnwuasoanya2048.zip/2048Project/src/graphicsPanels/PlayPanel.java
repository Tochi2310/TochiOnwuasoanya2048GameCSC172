package graphicsPanels;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;

import gameLogic.DrawUtils;
import gameLogic.Game;
import gameLogic.GameBoard;
import gameLogic.ScoreManager;


//Draws the actual 2048 game
public class PlayPanel extends GuiPanel {

	private GameBoard board;
	private BufferedImage info; // The image that draws all the scores and times
	private ScoreManager scores; // Obtained from game board
	private Font scoreFont; // Makes sure everything uses the same font
	private String timeF; // Draws the time onto the panel
	private String bestTimeF; // Draws the best time onto the panel

	// All of this is for the what happens when the game is over
	private GuiButton Restart; // Will allow the user to try again without restarting the application. Instead
								// of inputting the letter "r" like in the project description because I figured
								// this makes more sense for a GUI application
	private GuiButton BackToMain; // Allows the user to go to the main menu
	private GuiButton quit;
	private int smallButtonWidth = 160; // Width of the smaller buttons i.e the "Try Again" button
	private int spacing = 20; // Spacing between the buttons
	private int largeButtonWidth = smallButtonWidth * 2 + spacing; // Width of the bigger buttons i.e. the "Main Menu"
																	// button
	private int buttonHeight =50; // Height of the buttons
	private boolean added;  //Keeps track of if we've already added buttons to the panel 
	private int alpha =0; // For the fade in effect
	private Font gameOverFont; // Font for the game over message
//private boolean screenshot;
	public PlayPanel() {
		scoreFont = Game.main.deriveFont(24f); // Sets the font of the scores to a size of 24
		gameOverFont = Game.main.deriveFont(65f); // Sets the game over font to a size of 70
		board = new GameBoard(Game.WIDTH / 2 - GameBoard.BOARD_WIDTH / 2, Game.HEIGHT - GameBoard.BOARD_HEIGHT - 20); //Sets the size of the board on the panel and offsets it by 20 units from the bottom of the screen
		scores = board.getScores(); // Score manager
		info = new BufferedImage(Game.WIDTH, 200, BufferedImage.TYPE_INT_RGB);

		BackToMain = new GuiButton(Game.WIDTH / 2 - largeButtonWidth / 2, 450, largeButtonWidth, buttonHeight); //Sets the position of the back to main menu button on the panel																												
		Restart = new GuiButton(BackToMain.getX(), BackToMain.getY() - spacing - buttonHeight, smallButtonWidth,
				buttonHeight); // Sets the position of the Restart button on the panel
       
	
		 quit = new GuiButton(Restart.getX() + Restart.getWidth() + spacing, Restart.getY(), smallButtonWidth, buttonHeight);
		
		Restart.setText("Restart");
		BackToMain.setText("Back to Main Menu");
		quit.setText("Quit Game");
	

		// Handles all the action events for when the user clicks on the try again
		Restart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				board.getScores().reset();
				board.reset(); // Resets the current scores once the user clicks try again
				alpha = 0; // Alpha is set back to 0 once the try again button is pressed

				// Removes the buttons once "Restart" is pressed
				remove(Restart);
				remove(BackToMain);
				remove(quit);
				

				added = false;
			}
		});
		// Handles all the action events for when the user clicks on the back to main button
		
		BackToMain.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GuiScreen.getInstance().setCurrentPanel("Menu"); // Goes back to the main menu
			}

		});
		// Handles all the action events for when the user clicks on the Quit Game button
		quit.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				System.exit(0);//Status that is passed in, using 0 means the system is exiting on a normal exit

				
				
			}
		});
		
	}

	private void drawGui(Graphics2D g) {
		// Format the times
		timeF = DrawUtils.formatTime(scores.getTime());
		bestTimeF = DrawUtils.formatTime(scores.getBestTime());
		
		//Draw the times
		Graphics2D g2d = (Graphics2D) info.getGraphics();
		g2d.setColor(Color.white); //Set to white because the background needs to be cleared 
		g2d.fillRect(0,0, info.getWidth(), info.getHeight()); 
		g2d.setColor(Color.lightGray);
		g2d.setFont(scoreFont);
		g2d.drawString(""+ scores.getCurrentScore(), 30, 40);
		g2d.setColor(Color.red);
		//Draws the string "best" + the best score, but it is drawn on the right side and subtracts 20 pixels for extra spacing
		g2d.drawString("Best: " + scores.getCurrentTopScore(), Game.WIDTH - DrawUtils.getMessageWidth("Best: " + scores.getCurrentTopScore(), scoreFont, g) -20,40);
		 
		//Same thing as the best score which is immediately above 
		g2d.drawString("Fastest:" + bestTimeF, Game.WIDTH - DrawUtils.getMessageWidth("Fastest:" + bestTimeF, scoreFont, g2d)-20, 90);
        g2d.setColor(Color.black); //Sets color to black
        g2d.drawString("Time:" + timeF, 30, 90);  //Displays the current time
        g2d.dispose();
        g.drawImage(info, 0, 0, null); //Takes the image that was just drawn to with the updated results to the main graphics elements
        
        
	}
	//Draws the game over screen
	 public void drawGameOver(Graphics2D g) {
		 g.setColor(new Color(222, 222, 222, alpha)); //Any number repeated like this makes a gray, this assortment of numbers makes a lighter gray that I wanted to have as the background of the game over screen
		 g.fillRect(0,0, Game.WIDTH, Game.HEIGHT);
		 g.setColor(Color.black);                                                    //Note: Because the user can't move (all the spaces are filled and none of the numbers can combine) that means any attempted move would be invalid, and subsequently, the game must end because no move can be made.
		                                                                            //Thus the following statements are drawn to the screen:
		 g.drawString("Invalid Move!", Game.WIDTH / 2  - DrawUtils.getMessageWidth("Invalid Move!", gameOverFont, g) / 2, 250); //Writing and positioning of the game over message
	     g.drawString("Game Over!", Game.WIDTH /2  - DrawUtils.getMessageWidth("Game Over!", gameOverFont, g) / 2, 350); //Writing and positioning of the game over message                                      
		
		 
		 }
	//Update function that updates alpha
	 @Override 
	 public void update() {
		 board.update();
		 if(board.isDead()) {
			 alpha++;
			 if(alpha > 170) alpha = 170; //This self corrects alpha and prevents it from becoming too dark
		 }
	 }
	 @Override
	 public void render(Graphics2D g) {
	drawGui(g);
	board.render(g);
	

if(board.isDead()) {
if(!added) {
	added = true; 
	add(BackToMain); 
	add(Restart); 
	add(quit);
	
}
drawGameOver(g);

}
super.render(g); //Will render the buttons last and then put them on top
}
}
		
