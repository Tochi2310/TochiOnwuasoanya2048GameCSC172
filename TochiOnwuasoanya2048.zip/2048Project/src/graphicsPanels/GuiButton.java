package graphicsPanels;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import gameLogic.DrawUtils;
import gameLogic.Game;

public class GuiButton {

	private State currentState = State.RELEASED;
	private Rectangle clickBox;  //This is going to handle the clicking of the mouse when it's in a box
	private ArrayList<ActionListener> actionListeners; //Listens and then gets called upon an action event like a click
     private String text = "";   //The text that's going to be on the actual button
	
     //The variables down below will help control the colors of button when it is released, hovered over, and pressed. There is also a variable for the font as well. 
		private Color released; //Color when the button is released
		private Color hover; //Color when the button is hovered over
		private Color pressed; //Color when the button is pressed
		private Font font = Game.main.deriveFont(22f); //Size of the font on the buttons

		
			public GuiButton(int x, int y, int width, int height) { //Creates a rectangle for the buttons 
				clickBox = new Rectangle(x, y, width, height);
					actionListeners = new ArrayList<ActionListener>();
					released = new Color(173, 177, 179); //Light gray
					hover = new Color(150, 156, 158);  //Darker gray
					pressed = new Color(111, 116, 117);	//Dark gray
				
					
			}
		public void update() {
			
		}
		
		public void render(Graphics2D g) {//Background of the button depending on which state it is in
			if(currentState == State.RELEASED) { //If the button is released then the color is set and filled into the box
				g.setColor(released);
				g.fill(clickBox);
			}
			else if(currentState ==State.HOVER) {
				g.setColor(hover);
				g.fill(clickBox);
				
			}
			else {
				g.setColor(pressed);
				g.fill(clickBox);
			}
			g.setColor(Color.white);
			g.setFont(font);                         //Centers the text on the x position 
			g.drawString(text, clickBox.x + clickBox.width / 2 - DrawUtils.getMessageWidth(text, font, g) / 2,
					            clickBox.y + clickBox.height /2 + DrawUtils.getMessageHeight( text, font, g) /2); //Centers the text on the y position
		}
		public void addActionListener(ActionListener listener) { //When the button gets clicked it will do whatever is in the action listener
			actionListeners.add(listener);
			
			
		}
		
		public void mousePressed(MouseEvent e) {
			if(clickBox.contains(e.getPoint())) {
				currentState = State.PRESSED;
			}
		}
        public void mouseReleased(MouseEvent e) { //Got to check and see if there was a click
			if(clickBox.contains(e.getPoint())) {
				for(ActionListener al : actionListeners) {
					al.actionPerformed(null);
				}
			}
		}
        public void mouseDragged(MouseEvent e) {//Checks if the click box that contains the points, if it does the current state is set to pressed, if it's not then it's going to be released
	if(clickBox.contains(e.getPoint())) {
		currentState = State.PRESSED;
	}
	else {
		currentState = State.RELEASED;
	}
}
        public void mouseMoved(MouseEvent e) {
	if(clickBox.contains(e.getPoint())){
		currentState = State.HOVER; //On the point = hover
	}
	else {
		currentState = State.RELEASED; //Off the point = released
	}
	
	}
        public int getX() {
    		return clickBox.x;
}
        public int getY() {
    		return clickBox.y;
}
      public int getWidth() {
    	  return clickBox.width;
      }
      public int getHeight() {
    	  return clickBox.height;
      }
      public void setText(String text) {      //This is to set the text on the bottom that will be displayed
	this.text = text;
      }
      private enum State{ 
		RELEASED,
		HOVER,
		PRESSED
	}
	}

