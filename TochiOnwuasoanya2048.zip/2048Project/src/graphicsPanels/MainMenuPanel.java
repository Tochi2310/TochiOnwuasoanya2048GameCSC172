package graphicsPanels;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import gameLogic.DrawUtils;
import gameLogic.Game;

public class MainMenuPanel extends GuiPanel { //Extends GuiPanel so that we have access to it's components

	private Font titleFont = Game.main.deriveFont(100f);    //Font and font size for the title
	private Font creatorFont = Game.main.deriveFont(24f);   //Font and font size for the author tag
	private String title = "2048";                       //Title of the game
	private String creator = "By Tochi Onwuasoanya";       //Author's  name
	
	private int buttonWidth = 220; //width of the main menu buttons
                               //This is the spacing between the buttons
	private int buttonHeight = 60; //Height of the main menu buttons
	
	public MainMenuPanel() {
		super();
		GuiButton playButton = new GuiButton(Game.WIDTH / 2 - buttonWidth / 2, 220, buttonWidth, buttonHeight);
		playButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				GuiScreen.getInstance().setCurrentPanel("Play");
			}
		});
		playButton.setText("Play");
		add(playButton);
		
		GuiButton scoresButton = new GuiButton(Game.WIDTH / 2 - buttonWidth / 2, 310, buttonWidth, buttonHeight);
		scoresButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				GuiScreen.getInstance().setCurrentPanel("GameRecords");
			}
		});
		scoresButton.setText("Scores");
		add(scoresButton);
		
		GuiButton exitButton = new GuiButton(Game.WIDTH / 2 - buttonWidth / 2, 400, buttonWidth, buttonHeight);
		exitButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				System.exit(0);

				//Status that is passed in, using 0 means the system is exiting on a normal exit
				
			}
		});
		exitButton.setText("Exit Game");
		add(exitButton);
	}

	@Override
	public void render(Graphics2D g) { //Overrides the render method
		super.render(g);  //Renders all the buttons
		g.setFont(titleFont); //Sets the title font
		g.setColor(Color.black); //Sets the text color
		g.drawString(title, Game.WIDTH / 2 - DrawUtils.getMessageWidth(title, titleFont, g) / 2, 150); //Draws the title and centers it
		g.setFont(creatorFont); //Font of buttons
		g.drawString(creator, 20, Game.HEIGHT -10); //Draws the author tag and positions it 10 units from the bottom of the screen
		
		
	}
}
