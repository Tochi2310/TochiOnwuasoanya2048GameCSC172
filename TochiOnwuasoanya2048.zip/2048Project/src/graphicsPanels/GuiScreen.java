package graphicsPanels;

import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.util.HashMap;
//This class just keeps track of what's the current panel and then just passes the updates, the rendering, and all the mouse events through to that panel 
//Handles all the click events and tells which panel gets the focus and which one gets to update and render
public class GuiScreen {

	private static GuiScreen screen;
	
	private HashMap<String, GuiPanel> panels;
	private String currentPanel = "";   //A string to keep track of the current panel. This string will be used to identify which panel to give focus to in the hashmap 
	
	private GuiScreen() { 
		panels = new HashMap<String, GuiPanel>();
		
	}
	public static GuiScreen getInstance() {
		if(screen == null) { //If screen is null then create a new gui screen
			screen = new GuiScreen();
			
		}
		return screen;
	}
	public void update() { //Basically says to check every single one just in case the panel array is empty and then it updates
		if(panels.get(currentPanel)!=null) {
			panels.get(currentPanel).update();
		
		}
	}
	

public void render(Graphics2D g) { //Renders the panel
	if(panels.get(currentPanel)!=null) {
		panels.get(currentPanel).render(g);
	}
}
 public void add(String panelName, GuiPanel panel) {//This method helps add panels or set the current panel
	 panels.put(panelName, panel); //Returns the previous value associated with the panel key
     
 
 }
 public void setCurrentPanel(String panelName) {//Takes in a panel name and this will set whichever panel should get focused on
	 currentPanel = panelName;
 }
 public void mousePressed(MouseEvent e) {
	 if(panels.get(currentPanel)!= null) {//AS long as the panel is not null the program gets the panel and passes the mouse event to that panel
		panels.get(currentPanel).mousePressed(e);
	 }
 }
public void mouseReleased(MouseEvent e) {
	 if(panels.get(currentPanel)!= null) {
			panels.get(currentPanel).mouseReleased(e);
		 }
 }
public void mouseDragged(MouseEvent e) {
	 if(panels.get(currentPanel)!= null) {
			panels.get(currentPanel).mouseDragged(e);
		 }
}
public void mouseMoved(MouseEvent e) {
	 if(panels.get(currentPanel)!= null) {
			panels.get(currentPanel).mouseMoved(e);
		 }
}
}
