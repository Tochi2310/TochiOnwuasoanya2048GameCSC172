package graphicsPanels;

import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

public class GuiPanel {

	private ArrayList<GuiButton> buttons;
	
	
	public GuiPanel() {
		buttons = new ArrayList<GuiButton>(); //This ArrayList will hold all of the buttons that will be updated and rendered
		//for(GuiButton b : buttons) { 
		//	b.update();
		}
	//}
	
	public void update() { 
		for(GuiButton b : buttons) { //Enhanced for loop because I don't want buttons to be able to be removing while it's looping through
			b.update();
		}
			
	}
public void render(Graphics2D g) { 
	for(GuiButton b : buttons) {
		b.render(g);
	}
}

public void add(GuiButton button ) { //Adds the gui button
	buttons.add(button);
}

public void remove(GuiButton button ) { //removes the gui button
	buttons.remove(button);
}


	public void mouseDragged(MouseEvent e) {
		for(GuiButton b : buttons) {
			b.mouseDragged(e);
		}
		
	}
	
	public void mouseMoved(MouseEvent e) {
		for(GuiButton b : buttons) {
			b.mouseMoved(e);
		}
		
	}
	
	
	
	public void mousePressed(MouseEvent e) {
		for(GuiButton b : buttons) {
			b.mousePressed(e);
		}
		
	}
	
	public void mouseReleased(MouseEvent e) {
		for(GuiButton b : buttons) {
			b.mouseReleased(e);
		}
		
	}
	


}

