package gameLogic;

import javax.swing.JFrame;

public class Start {

	
	public static void main(String[] args) {
	Game game = new Game();
	
	JFrame window = new JFrame("2048"); 
	window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	window.setResizable(false);
	window.add(game);
	window.pack();
	window.setLocationRelativeTo(null); //Centers the frame on the screen when we test it out
	window.setVisible(true);
	
	game.start(); //Starts the initial thread
		
	}
}
