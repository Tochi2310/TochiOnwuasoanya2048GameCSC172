package gameLogic;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;



public class Tile {
	  
	//Public because the game board class needs to know these variables as well
	public static final int WIDTH = 100; //Width of the tile
	public static final int HEIGHT = 100; //Height of tile
	public static final int SLIDE_SPEED = 30; //Speed per update at which the tiles move across when a movement key is pressed
	public static final int ARC_WIDTH = 15; //Roundness of the tile width wise
	public static final int ARC_HEIGHT = 15; //Roundness of the tile height wise
	
	//Private because only this class needs to know about these variables
	private int value;
	private BufferedImage tileImage; //The background in the text on it
	private Color background; //Background color
	private Color text; //Text color
	private Font font; //For the font of the text
	private Point slideTo; //
	private int x; //Coordinates for where to draw on the screen
	private int y;  //Coordinates for where to draw on the screen
    private boolean beginningAnimation = true;
	private double scaleFirst =0.1; 
	private BufferedImage beginningImage;
	
	private boolean combineAnimation = false;
	private double scaleCombine =1.2;
	 private BufferedImage combineImage;

	   private boolean canCombine = true;           //Point that stores the row and column where the tile needs to go to
	public Tile(int value, int x, int y) { // value and x and y position
		this.value = value;
		this.x = x;
		this.y = y;
		slideTo = new Point(x,y); //Prevents the tile from sliding to coordinates like 0,0
		tileImage = new BufferedImage(WIDTH, HEIGHT, BufferedImage.TYPE_INT_ARGB); //This is the tile image
		beginningImage = new BufferedImage(WIDTH, HEIGHT, BufferedImage.TYPE_INT_ARGB);
		combineImage = new BufferedImage(WIDTH *2, HEIGHT *2, BufferedImage.TYPE_INT_ARGB);
		drawImage();           //This will draw to the tile image
	}
	//Method to draw Image
	private void drawImage() {
		Graphics2D g = (Graphics2D)tileImage.getGraphics(); //Will get the graphics elements of the tile image so it can be drawn to
	    if(value == 2) {
	    	background = new Color(0xe9e9e9); //Color grey
	    	text = new Color(0x000000); //Color black
	    	    }
	    else if(value == 4) {
	    	background = new Color(0xe6daab);
	    	text = new Color(0x000000);
	    	
	    }
	    else if(value == 8) {
	    	background = new Color(0xf79d3d);
	    	text = new Color(0xffffff); //White text
	    	
	    }
	    else if(value == 16) {
	    	background = new Color(0xf28007);
	    	text = new Color(0xffffff);
	    	
	    }
	    else if(value == 32) {
	    	background = new Color(0xf55e3b);
	    	text = new Color(0xffffff);
	    	
	    }
	    else if(value == 64) {
	    	background = new Color(0xff0000); //red
	    	text = new Color(0xffffff);
	    	
	    }
	    else if(value == 128) {
	    	background = new Color(0xe9de84);
	    	text = new Color(0xffffff);
	    	
	    }
	    else if(value == 256) {
	    	background = new Color(0xf6e873);
	    	text = new Color(0xffffff);
	    	
	    }
	    else if(value == 512) {
	    	background = new Color(0xf5e455);
	    	text = new Color(0xffffff);
	    	
	    }
	    else if(value == 1024) {
	    	background = new Color(0xf7e12c);
	    	text = new Color(0xffffff);
	    	
	    }
	    else if(value == 2048) {
	    	background = new Color(0xffe400);
	    	text = new Color(0xffffff);   	
	    }
	    else { //If it is any other value than the ones above then the background and text will just be set to black and white respectively 
	    	background = Color.black;
	    	text = Color.white;    	
	    }
 g.setColor(new Color(0,0,0)); //Transparent color
 g.fillRect(0, 0, WIDTH, HEIGHT); //Fill in rectangle
 
 g.setColor(background);
 g.fillRoundRect(0,0, WIDTH, HEIGHT, ARC_WIDTH, ARC_HEIGHT);
 
 g.setColor(text);
 
 if(value <= 64) {
	 font = Game.main.deriveFont(36f);
	  }
 else {
	 font = Game.main;
 }
 g.setFont(font);
 
 int drawX = WIDTH / 2 - DrawUtils.getMessageWidth("" + value, font, g) / 2; //Basically this is going to get the width divided by 2 (the center) and then move to the left half of the message width. That will eventually get the top x coordinate for centering the message.
 int drawY = HEIGHT / 2 + DrawUtils.getMessageHeight("" + value, font, g) / 2; // Used "+" here because when you draw letters in Java it starts from the bottom left not the top left corner so you have to add half the height instead of subtracting half
	g.drawString("" + value, drawX, drawY);
	g.dispose();
	}
	
	public void update() {
	if(beginningAnimation) {
		AffineTransform transform = new AffineTransform(); //For scaling
		transform.translate(WIDTH / 2 - scaleFirst * WIDTH / 2, HEIGHT /2 - scaleFirst * HEIGHT / 2);
	    transform.scale(scaleFirst,  scaleFirst);
	    Graphics2D g2d = (Graphics2D) beginningImage.getGraphics();
	    g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
	    g2d.setColor(new Color(0,0,0,0));
	    g2d.fillRect(0, 0, WIDTH,  HEIGHT);
	    g2d.drawImage(beginningImage, transform, null);
	    scaleFirst += 0.1;
	    g2d.dispose();
	    if(scaleFirst >= 1)beginningAnimation = false;	
	}
	else if(combineAnimation) {
		AffineTransform transform = new AffineTransform(); //For scaling
		transform.translate(WIDTH / 2 - scaleCombine * WIDTH / 2, HEIGHT /2 - scaleCombine * HEIGHT / 2);
	    transform.scale(scaleCombine,  scaleCombine);
	    Graphics2D g2d = (Graphics2D) combineImage.getGraphics();
	    g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
	    g2d.setColor(new Color(0,0,0,0));
	    g2d.fillRect(0, 0, WIDTH,  HEIGHT);
	    g2d.drawImage(tileImage, transform, null);
	    scaleCombine -= 0.5;
	    g2d.dispose();
	    if(scaleCombine <= 1)
	    	combineAnimation = false;	
	}
	}
	public void render(Graphics2D g) {
		if(beginningAnimation) {
			g.drawImage(beginningImage, x, y, null);
		}
		else if(combineAnimation) {
			g.drawImage(combineImage,(int)( x + WIDTH /2 - scaleCombine * WIDTH / 2), 
					                 (int)( y + WIDTH /2 - scaleCombine * WIDTH / 2), null);
	}
		else {
			g.drawImage(tileImage, x, y, null);
		}
		
	}
	
	public int getValue() {
		return value;
	}
	public void setValue(int value) {
		this.value = value;
		drawImage();
	}
	public boolean canCombine() {
		return canCombine;
	}
	
	public void setCanCombine(boolean canCombine) {
		this.canCombine = canCombine;
	}
	
	public Point getSlideTo() {
		return slideTo;
	}
	
	public void setSlideTo(Point slideTo) {
		this.slideTo = slideTo;
	}
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	public boolean isCombineAnimation() {
		return combineAnimation;
	}
	public void setCombineAnimation(boolean combineAnimation) {
		this.combineAnimation = combineAnimation;
		if(combineAnimation) scaleCombine = 1.2; 
	}
}
