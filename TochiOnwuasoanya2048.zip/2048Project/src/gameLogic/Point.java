package gameLogic;

//
public class Point {
 
	public int row;
	public int col;
	//Stores a position that goes by row and column
	public Point(int row, int col) {
		this.row = row;
		this.col =col;
	}
}
