package gameLogic;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;

import javax.swing.JPanel;

import graphicsPanels.GameRecordsPanel;
import graphicsPanels.GuiScreen;
import graphicsPanels.MainMenuPanel;
import graphicsPanels.PlayPanel;



//Using this panel for drawing, and it's going to be added to the frame
//Implementing Runnable allows the thread to be made 
//and KeyListener helps capture key events of text input components  //Mouse Listener helps process mouse events (press, release, click, enter, and exit) on a component.           
//MouseMotionListener helps o track mouse moves and mouse drags
public class Game extends JPanel implements KeyListener, MouseListener, MouseMotionListener, Runnable{
	private static final long serialVersionUID = 1L;
//These won't be changed after the game starts running because the screen being resizable was set to false
	public static final int WIDTH = GameBoard.BOARD_WIDTH + 40;// Width of game panel
	public static final int HEIGHT = 630; // Height of game panel
	public static final Font main = new Font("Bebas Neue Regular", Font.PLAIN, 28);//Sets the font and makes it non-bolded and non-italicized
	private Thread game;
	private boolean running; //Keeps track of if the game thread is running for starting and stopping the thread
	//All the drawing is going to be done on this image using this images graphics and then that'll be drawn to the J panels graphics
	private BufferedImage image = new BufferedImage(WIDTH, HEIGHT, BufferedImage.TYPE_INT_RGB);
	private GuiScreen screen; //This acts as the screen manager
	
	
	private long startTime; //This is for keeping track of if we should update
	private long elapsed; 
	private boolean set; 
	
	public Game() {
		setFocusable(true); //This allows keyboard input to be set
		setPreferredSize(new Dimension( WIDTH, HEIGHT));//Will determine how big the frame is
	    addKeyListener(this);
	    addMouseListener(this);
	    addMouseMotionListener(this);
	                              
	   
	screen = GuiScreen.getInstance();
	screen.add("Menu", new MainMenuPanel());
	screen.add("Play",  new PlayPanel()); //Adds another panel to the list of panels
	screen.add("GameRecords", new GameRecordsPanel());
	screen.setCurrentPanel("Menu");
	}
	private void update() { //Will be called 60 times a second
		screen.update();
		Keyboard.update();
		
	}
	private void render() { //Will also be called 60 times a second
		Graphics2D g = (Graphics2D) image.getGraphics(); //This is the actual image that is being drawn to. It's a virtual image that is stored in memory that keeps track of everything we're drawing on the screen. All the game board and pieces are drawn to this image
	    g.setColor(Color.white); //Sets the color of the background to white
	    g.fillRect(0, 0, WIDTH, HEIGHT); //Draws a white rectangle around the screen
	    // render screen
	    screen.render(g);
	    g.dispose(); //Disposes of this graphics context and releases any system resources that it is using. A Graphics object cannot be used after dispose has been called.
       //Gets the graphics of the JPanel and draws the final image to the JPanel
	    Graphics2D g2d = (Graphics2D)getGraphics(); //The actual J panels graphics that is drawn on
	    g2d.drawImage(image, 0, 0, null);
	    g2d.dispose();
	}
	@Override
	public void run() { //Called when the thread is started
		int fps =0, updates = 0; //Prints out how many updates in frame per seconds the program is getting
		long fpsTimer = System.currentTimeMillis(); 
	    double nsPerUpdate = 1000000000.0/60; //Keeps tracks of how many nanoseconds between updates there are because we want to get the target of 60 frames per second. Dividing a billion by 60 because a billion nanoseconds are in one second

	//last update time in nanoseconds
	    double then =System.nanoTime();
	    double unprocessed = 0; //Keeps track of how many updates the program needs to do just in case the rendering falls behind
	   //This will check while it's running if running gets called false it will stop updating and rendering
	  //On each loop it will set should render to false and it's gonna get the new time and check to see if it's unproccesed if it needs to update, update if it can, sleep if it should, and render if it can
	    while(running) {
	    	
	    	boolean shouldRender = false; //Want to lock the frames per second at sixty 
	    	double now = System.nanoTime();          //While it's running we now have to get the new time
	        unprocessed +=(now - then) / nsPerUpdate; //Counts how many updates we need to do based on how much time has passed and then set the then to now because we have to reset the time now
	        then = now; 
	        
	    
	    //update queue 
	    while(unprocessed >= 1) {
	    updates++;
	    update();
	    unprocessed--;
	    shouldRender = true;//Only want to render once it's updated 
	    
	    }
	    //Render
	    if(shouldRender){
	    	fps++;
	    	render();
	    	shouldRender = false;
	    }
	    else { //This will pause the thread if it's not rendering 
	    	try {
	    		Thread.sleep(1);
	    	} catch(Exception e) {
	    		e.printStackTrace(); //Prints out any potential error
	    	}
	    }
	    //FPS timer
	    if(System.currentTimeMillis() - fpsTimer > 1000) { //Current time minus how much time has passed and if it is greater than a full second then 
	    	System.out.printf("%d fps %d updates" , fps, updates);
	    	System.out.println("");
	    	fps = 0;
	    	updates = 0;
	    	fpsTimer += 1000; //Resets the FPS timer
	    }
	    }
	}
	//Synchronized because it makes sure that the thread manager won't switch threads in the middle  
	    public synchronized void start() { //This method is responsible for the start of the thread
	    	if(running)
	    		return;
	    	running = true; //Will make it able to go through the loop
	       game = new Thread(this, "game"); //Named it "game" for potential debugging purposes
	        game.start(); //Begins execution of the thread
	    }
	public synchronized void stop() {//This method stops the thread if running is false and exits
		if(!running)
			return;
		running = false; 
		System.exit(0);
	}

	@Override
	//This method gets called when a key is pressed
	public void keyPressed(KeyEvent e) {
		Keyboard.keyPressed(e);
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		Keyboard.keyReleased(e);
		
	}

	@Override
	public void keyTyped(KeyEvent e) {
   
		
		
	}
	@Override
	public void mouseDragged(MouseEvent e) {
		 screen.mouseDragged(e);
		
	}
	@Override
	public void mouseMoved(MouseEvent e) {
		 screen.mouseMoved(e);
		
	}
	@Override
	public void mouseClicked(MouseEvent e) {
		
		
	}
	@Override
	public void mousePressed(MouseEvent e) {
		 screen.mousePressed(e);
		
	}
	@Override
	public void mouseReleased(MouseEvent e) {
		 screen.mouseReleased(e);
		
	}
	@Override
	public void mouseEntered(MouseEvent e) {
		
		
	}
	@Override
	public void mouseExited(MouseEvent e) {
		
		
	}

}
