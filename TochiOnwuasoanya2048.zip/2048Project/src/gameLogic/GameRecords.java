package gameLogic;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.util.ArrayList;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.util.ArrayList;

//Seperates high scores from current scores and saves the scores in a permanent file
public class GameRecords {

	private static GameRecords lBoard;
	private String filePath;
	private String highScores;
	
	
	//All time leaderboards
	private ArrayList <Integer> topScores; //Users highest scores
	private ArrayList <Long> topTimes;  //Users fastest times
	
	private GameRecords() {
		
			filePath = new File("").getAbsolutePath(); //Returns the absolute pathname string of this abstract pathname. 
		
		    highScores = "Scores";
		    
		    topScores = new ArrayList<Integer>();
		    
		    topTimes = new ArrayList<Long>();
	
	
	}
	public static GameRecords getInstance() {
		if(lBoard == null) {
			lBoard = new GameRecords();
		}
	   return lBoard;
	}
	public void addScore(int score) {  //Takes in an integer of what score the user will add
	for(int i =0; i< topScores.size(); i++) {
		if(score >= topScores.get(i)) {        //Basically this is going to go through it and if the user has a high score it will add it
			topScores.add(i, score);           //add it there in that position pushing all the elements back one and then removes the last element at the very end 
			topScores.remove(topScores.size() -1); 
		}
	}
	      }           
	            
		public void addTime(long millis)  {
		for(int i=0; i<topTimes.size(); i++)	{
			if(millis<= topTimes.get(i)) {
				topTimes.add(i,millis );
				topTimes.remove(topTimes.size()-1);
				return;
			}
		}
		}
	
                         //Three rows of 5 scores each
		public void loadScores() {
			try {
				File f = new File(filePath, highScores);
				if(!f.isFile()) {
					createSaveData();
					
				}
				BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(f))); //Creates a buffered reader from the file F
				//Every time the scores are loaded it is necessary  to make sure that the previous scores and times are cleared
				topScores.clear();  
			        topTimes.clear();  
			        //String array that holds the top scores, tiles, and times
			      String[] scores = reader.readLine().split("-"); 
			      String[] times = reader.readLine().split("-");
			      
			      //Iterates through the various scores  
			      for(int i=0; i < scores.length; i++) {
			    	  topScores.add(Integer.parseInt(scores[i]));
			      }
                 
			
                  for(int i=0; i < times.length; i++) {
                	  topTimes.add(Long.parseLong(scores[i]));
 }
                  reader.close();
			      
			}catch(Exception e) {
				e.printStackTrace();
			}
		}

      //Save Scores method
		public void saveScores() {
			FileWriter output = null;
			try {
				File f = new File(filePath, highScores);	
				 output = new FileWriter(f)  ;                    //Seperate file that only needs to get saved to at the end of the game
			     BufferedWriter writer = new BufferedWriter(output);
			
			     //Adds each score from best to worst and seperate them with dashes so they're easier to load in
			      writer.write(topScores.get(0) + "-"  + topScores.get(1) + "-" + topScores.get(2) + "-" + topScores.get(3)+"-" + topScores.get(4));
			      writer.newLine();
			      writer.write(topTimes.get(0) + "-"  + topTimes.get(1) + "-" + topTimes.get(2) + "-" + topTimes.get(3)+"-" + topTimes.get(4));
			      writer.close();					
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		private void createSaveData() {
			FileWriter output = null;
			try {
				File f = new File(filePath, highScores);	
				 output = new FileWriter(f)  ;                    //Seperate file that only needs to get saved to at the end of the game
			     BufferedWriter writer = new BufferedWriter(output);
			
			      writer.write("0-0-0-0-0");
			      writer.newLine();
			      writer.write( "0-0-0-0-0"    );
			      writer.newLine();
			      writer.write( Integer.MAX_VALUE + "-" + Integer.MAX_VALUE + "-" + Integer.MAX_VALUE + "-" + Integer.MAX_VALUE+ "-" + Integer.MAX_VALUE );
			      writer.close();					
			}catch(Exception e) {
				e.printStackTrace();
			}
			
			
		}
		//These getters just return the high scores, and top times by getting the first element of each array
		public int getHighScore() {
			return topScores.get(0);
			
		}
		public ArrayList<Integer> getTopScores() {
			return topScores;
		}
	
	
		
		public ArrayList<Long> getTopTimes() {
			return topTimes;
		}
		
		public long getFastestTime() {
			return topTimes.get(0);
		}
		
}
