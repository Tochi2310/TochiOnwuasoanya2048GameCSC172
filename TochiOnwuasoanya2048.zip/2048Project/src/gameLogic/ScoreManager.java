package gameLogic;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;


//This class is to save the game continuously and to write to a temporary file that is deleted once the game ends but is recreated a new game starts
//Knows high scores and the users current score
public class ScoreManager {

	//Current Scores
	private int currentScore;
	private int currentTopScore;
	private long time;
	private long startingTime;
	private long bestTime;
	private int[] board = new int[GameBoard.ROWS * GameBoard.COLS];

	//File stuff
		private String filePath;
		private String temp = "TEMP.exe"; //New file type
		private GameBoard gBoard; //Copy of the gameboard 

	// New game boolean that helps in the reset method and in the createfile one as well
	private boolean newGame;

	public ScoreManager(GameBoard gBoard) {
		this.gBoard = gBoard;
		
	    filePath = new File("").getAbsolutePath(); //Gets to the file location
		}
	  //Method for when the game is lost and it needs to be reset
		public void reset() {
			File f = new File(filePath, temp);  //Saves the file by grabbing it at the file path
			if(f.isFile()) {
				f.delete();
			}
			newGame = true;
			startingTime = 0;
			currentScore = 0;
			time = 0;
		}
	private void createFile() {   //Going to create the save file if it doesn't exist already
	FileWriter output = null;
	newGame = true;

	    try {
		 
	    	File f = new File(filePath, temp);  //Serves as the directory of the file
	    	output = new FileWriter(f);
	    	BufferedWriter writer = new BufferedWriter(output);
	    	writer.write("" + 0);
	    	writer.newLine();
	    	writer.write("" + 0);
	    	writer.newLine();
	    	writer.write("" + 0);
	    	writer.newLine();
	    	writer.write("" + 0);
	    	writer.newLine();
	    	
	    	//Double for loop here goes through and saves the game board
	    	for(int row =0; row<GameBoard.ROWS; row++) {
	    		for(int col =0; col<GameBoard.COLS; col++) {
	        		if(row == GameBoard.ROWS - 1 && col == GameBoard.COLS -1) {
	        			writer.write("" + 0);
	        			
	        		}
	        		else { //Makes it easier to know where each tile started and ended
	        			writer.write(0 + "-");  
	        		}
	        		
	        	}
	    		
	    	}
	    	writer.close();
	       }catch(Exception e) {
	    	   e.printStackTrace();
	    	   
	}
	}
	//Save game methods
	//The logic behind this entire class is that the integer array gets updated on the game based off the game board, and then it will save to the file
	public void saveGame() {
	FileWriter output = null; //Writes to the file
	if(newGame)newGame = false; //

	try {
	  File f = new File(filePath, temp);
		output = new FileWriter(f); //File writer made of of file f
		BufferedWriter writer = new BufferedWriter(output); 
		writer.write("" + currentScore);
		writer.newLine();
		writer.write("" + currentTopScore);
		writer.newLine();
		writer.write("" + time);
		writer.newLine();
		writer.write("" + bestTime);
		writer.newLine();
		
		
		for(int row =0; row<GameBoard.ROWS; row++) {
			for(int col =0; col<GameBoard.COLS; col++) {
	    		//Converts 2D coordinates to 1D in order to get location. Ex: row = 3 col =2 --> 12 +2 =14
				int location = row * GameBoard.COLS + col;
				Tile tile = gBoard.getBoard()[row][col];
				//When the game is loaded back up it will check if it's 0 and if it is then the location on the board is null
			 this.board[location] = tile!=null ? tile.getValue() : 0; //gets the current tile at the game board
			  
			   if(row == GameBoard.ROWS - 1 && col == GameBoard.COLS - 1) {
				   writer.write("" + board[location]); //
	   			
	   		}
	   		else {
	   			writer.write(board[location] + "-");  
	   		}
	   		
	   	}
			
		}
		writer.close();
	  }catch(Exception e) {
		   e.printStackTrace();
		   
	}
	}

		public void loadGame() { 
			try {
				File f = new File(filePath, temp); //Gets the file
				
				if(!f.isFile()) { //If F is not a file then a file needs to be created by calling createfile()
				createFile();	
					
				}
			                          
				BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(f)));
		         currentScore = Integer.parseInt(reader.readLine());
		         currentTopScore = Integer.parseInt(reader.readLine());
			      time = Long.parseLong(reader.readLine());
			      startingTime = time; //Allow users to close out of the game, have the clock stop, and the have the clock start once the program is reopenned
			      bestTime = Long.parseLong(reader.readLine());
			      
			      String [] board = reader.readLine().split("-") ;    ///String array that holds the game data so that it can be loaded back into the game
			     for( int i=0; i<board.length; i++) {      //Parses all those strings and numbers
			   	 this.board[i] = Integer.parseInt(board[i]);
			  }
			      reader.close();
			}catch(Exception e) {
				e.printStackTrace();
				
			}
		}
		public int getCurrentScore() {
			return currentScore;
		}
		public void setCurrentScore(int currentScore) {
			this.currentScore = currentScore;
		}
		public int getCurrentTopScore() {
			return currentTopScore;
		}
		public void setCurrentTopScore(int currentTopScore) {
			this.currentTopScore = currentTopScore;
		}
		public long getTime() {
			return time;
		}
		public void setTime(long time) {
			this.time = time + startingTime;  
		}
		public long getBestTime() {
			return bestTime;
		}
		public void setBestTime(long bestTime) {
			this.bestTime = bestTime;
		}
		public int[] getBoard() {
			return board;
		}
		
		public boolean newGame() {
			return newGame;
		}
		
	    		
	  


	}


