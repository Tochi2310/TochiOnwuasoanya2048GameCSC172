package gameLogic;

import java.awt.event.KeyEvent;

//Keeps track of all pressed event and can return if it's typed, pressed, or released
public class Keyboard {

	public static boolean[] pressed = new boolean[256];
	public static boolean[] prev = new boolean[256];
	
	


public static void update() {//Sets everything in the previous array equal to the pressed array
	for(int i=0; i<4; i++) {//Because only 4 keys are used, there's no point in looping through all 256 in the pressed array, so instead it will be looped 4 times (up, down, left, right)
	   if(i == 0)prev[KeyEvent.VK_A] = pressed[KeyEvent.VK_A];
	   if(i == 1)prev[KeyEvent.VK_D] = pressed[KeyEvent.VK_D];
	   if(i == 2)prev[KeyEvent.VK_W] = pressed[KeyEvent.VK_W];
	   if(i == 3)prev[KeyEvent.VK_S] = pressed[KeyEvent.VK_S];
	
	}
}
//If you press a key, it sets the key pressed to true then that updates the game board, so the game board checks for what keys are true and what should be moved. Then at the end of the update loop in the game class it's going to set all the previous keys to the pressed keys and will set it as true or false.   
public static void keyPressed(KeyEvent e) { 
 pressed[e.getKeyCode()] = true;  //True because you are pressing the keys

}
 public static void keyReleased(KeyEvent e) { 
	 pressed[e.getKeyCode()] = false;  //False because you're no longer pressing the keys
	 
 }
 public static boolean typed(int keyEvent) { //captures the key typed event
	 return pressed[keyEvent] && prev[keyEvent]; //Return if the pressed at key event is not true but the previous state is true.Basically, if you release the key then for a split second the pressed event is going to be false and the previous event is going to be true it's then going to get updated and the previous event is going to be false and so this typed method will only be called once
 }

}  
