package gameLogic;

import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.font.TextLayout;
import java.awt.geom.Rectangle2D;
//Two helper methods
public class DrawUtils {

	
		//Will see how wide the message is and with that knowledge we can center it on the tile
		public static int getMessageWidth(String message, Font font, Graphics g) {
			g.setFont(font);
			Rectangle2D bounds = g.getFontMetrics().getStringBounds(message, g); //Creates a rectangle out of the boundaries of whatever the font is and the message 
	        return(int)bounds.getWidth(); //Returns the width
		}

		//Will see how high the message is and with that knowledge it can be centered on the tile
		public static int getMessageHeight(String message, Font font, Graphics2D g) {
			g.setFont(font);
			if(message.length() == 0) return 0;
			TextLayout tl = new TextLayout(message, font, g.getFontRenderContext());   //Lets us know how big a message is
		     return(int)tl.getBounds().getHeight();
		}
		
	// This entire method here helps format the time that is displayed on the application
		public static String formatTime(long millis) {
			String formattedTime ="";
			int hours = (int) (millis /3600000);
			if(hours>=1) {
				millis = hours * 3600000;
				formattedTime += hours + ":";
			}
			int minutes = (int)(millis / 60000);
			if(minutes >= 1) {
				millis -= minutes * 60000;
				if(minutes <10) {
					formattedTime += minutes + ":";
				}
				else {
					formattedTime += minutes + ":";
				}
			}
			int seconds = (int) (millis / 1000);
			if(seconds >= 1) {
				millis -= seconds * 1000;
				if( seconds < 10) {
					formattedTime += "0" + seconds + ":";
				}
				else {
					formattedTime += seconds + ":";
				}
			}
			if(millis >99) {
				formattedTime += millis;
			}
			else if (millis >9) {
				formattedTime += "0" + millis;
			}
			else {
				formattedTime += "00" + millis;
			}
			return formattedTime;
		}
	}

